package com.mx.Videojuego;

public interface IMetodos {
// METODOS CRUD
	public void crear (Videojuego v);
	public void listar ();
	public void actualizar (int indice, Videojuego v);
	public void eliminar (int indice);
	
	
}
