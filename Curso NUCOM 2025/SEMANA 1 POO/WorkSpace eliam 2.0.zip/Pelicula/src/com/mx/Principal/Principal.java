package com.mx.Principal;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Principal {

	public static void main (String [] args ){
		
		//PELICULAS 
		
		Pelicula p1 = new Pelicula ("MINECRAFT", "ACCION Y FICCION", "ESPAÑOL", "3:30HRS",10.50,"10/07/2025");
		Pelicula p2 = new Pelicula ("STAR WARS", "ACCION Y FICCION", "INGLES Y ESPAÑOL", "2:30HRS", 5.65,"16/07/2025");
		Pelicula p3 = new Pelicula ("COMO ENTRENAR A TU DRAGON", "FAMILIAR", "ESPAÑOL", "2:30HRS",10.50,"19/07/2025");
		Pelicula p4 = new Pelicula ("FORMULA 1", "ACCION", "ESPAÑOL", "1:30HRS",7.50,"10/07/2025");
		Pelicula p5 = new Pelicula ("FUERZA REGIDA Y SU BANDA ", "ACCION", "ESPAÑOL ", "2:30HRS",10.50,"10/07/2025");
		Pelicula p6 = new Pelicula ("EL CHAVAL", "INFANTIL", "ESPAÑOL", "2:40HRS",8.50,"16/07/2025");
		
		Pelicula aux = null;
		//crear lista 
		
		List<Pelicula> peliculas = new ArrayList<Pelicula>();
		//VALIABLE LOCALES 
		//agregar 
		peliculas.add(p1);
		peliculas.add(p2);
		peliculas.add(p3);
		peliculas.add(p4);
		peliculas.add(p5);
		peliculas.add(p6);
		
		String nombre,categoria,lenguaje,duracion,fecha;
		double precio;
		int indice = 0, menuP = 0, menuE = 0;
		
		Scanner teclado =  null;
		do {
			System.out.println("*******************MENU PELICULAS*****************");
			System.out.println("1. AGREGAR");
			System.out.println("2. BUSCAR");
			System.out.println("3. MOSTRAR");
			System.out.println("4. ELIMINAR");
			System.out.println("5. EDITAR");
			System.out.println("6. SALIR");
			teclado = new Scanner(System.in);
			menuP = teclado.nextInt();
			
			
			switch(menuP) {
			
			case 1:
				System.out.println("********************ALTA DE PELICULA***************");
				System.out.println("INGRESA EL NOMBRE DE LA PELICULA");
				teclado = new Scanner(System.in);
				nombre = teclado.nextLine();
				
				System.out.println("INGRESA LA CATEGORIA DE LA PELICULA");
				teclado = new Scanner(System.in);
				categoria = teclado.nextLine();
				
				System.out.println("INGRESA EL LENGUAJE DE LA PELICULA ");
				teclado = new Scanner(System.in);
				lenguaje = teclado.nextLine();
				
				System.out.println("INGRESA LA DURACION DE LA PELICULA");
				teclado = new Scanner(System.in);
				duracion = teclado.nextLine();
				
				System.out.println("INGRESA EL PRECIO DE LA PELICULA");
				teclado = new Scanner(System.in);
				precio = teclado.nextDouble();
				
				System.out.println("INGRESA LA FECHA DE ESTRENO DE LA PELUCULA");
				teclado = new Scanner(System.in);
				fecha = teclado.nextLine();
				
				//crear el objeto aux
				
				aux = new Pelicula (nombre,categoria,lenguaje,duracion,precio,fecha);
				//agregarlo a la lista 
				peliculas.add(aux);
				
				System.out.println("LA PELICULA " + aux.getNombre() + " DE CATEGORIA " + aux.getCategoria() + "SE HA AGREGADO CORRECTAMENTE");
				break;
			case 2:
				System.out.println("***********************BUSCAR PELICULAS***********************");
				System.out.println("Ingresa el indice a buscar");
					teclado = new Scanner(System.in);
					indice = teclado.nextInt();
					aux = peliculas.get(indice);
					System.out.println("Pelicula localizada " + aux);
				break;
			case 3:
				System.out.println("************************MOSTAR CELULARES*****************");
				System.out.println(peliculas);
			   
			    break;
			case 4:
				System.out.println("***************ELIMINAR PELICULA**************");
				System.out.println("Ingresa el indice a eliminar ");
				teclado = new Scanner(System.in);
				indice = teclado.nextInt();
				aux = peliculas.get(indice);
				peliculas.remove(indice);
				System.out.println("SE HA ELIMINADO LA SIGUINETE PELICULA" + " " + aux.getNombre() + "DE CATEGORIA" + aux.getCategoria() );
				break;
			case 5: 
				System.out.println("**************************************EDITAR PELICULA**************************");
				System.out.println("Ingresa el indice a editar");
				teclado = new Scanner(System.in);
				indice = teclado.nextInt();
				
				
				do {
					System.out.println("************************************* MENU EDITAR****************************");
					System.out.println("1. NOMBRE" + "\n2. CATEGORIA " + "\n3 LENGUAJE" + "\n4 REGISTRAR" + "\n5 Ingresa una opcion valida");
				teclado = new Scanner(System.in);
				menuE = teclado.nextInt();
				
				switch(menuE) {
				case 1:
					System.out.println("Ingresa el nuevo nuevo nombre");
					teclado = new Scanner(System.in);
				nombre = teclado.nextLine();
				aux.setNombre(nombre);
				System.out.println("EL NOMBRE SE HA ACTUALIZADO.");
					break;
				case 2: 
					System.out.println("Ingresa la categoria");
					teclado = new Scanner(System.in);
				categoria = teclado.nextLine();
				aux.setCategoria(categoria);
				System.out.println("CATEGORIA ACTUALIZADA.");
					break;
				case 3: 
					System.out.println("Ingresa el lenguaje");
					teclado = new Scanner(System.in);
				lenguaje = teclado.nextLine();
				aux.setLenguaje(lenguaje);
				System.out.println("EL LENGUAJE SE HA ACTUALIZADO.");
					break;
				case 4: 
					System.out.println("ACTUALIZANDO...................");
					peliculas.set(indice, aux);
					System.out.println("Regresando al menu principal");
					break;
					default:
						System.out.println("ERROR, OPCION INCORRECTA. ELIGE UNA OPCION VALIDA");
				}
				}while(menuE != 4); //cierre de segundo do-while 
				break;
			case 6:
				System.out.println("SALIENDO DE LA APLICACION...................\n ¡HASTA PRONTO!");
			break;
			default:
				
			}
			
			
		}while (menuP != 6);
	}
	
	
}
