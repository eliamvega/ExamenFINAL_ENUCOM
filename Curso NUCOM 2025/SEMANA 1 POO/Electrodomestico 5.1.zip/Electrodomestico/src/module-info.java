/**
 * 
 */
/**
 * 
 */
module Electrodomestico {
}