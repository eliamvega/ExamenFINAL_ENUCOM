package com.mx.Electrodomestico;

public interface IMetodos {

	
	public void guardar (Electrodomestico e);
	public void mostrar ();
	public void editar (Electrodomestico e);
	public void eliminar (Electrodomestico e);
	void crear(Electrodomestico e);

	
}
