package com.mx.Examen1;

public interface Entregable {
    void entregar();
    void devolver();
    boolean isEntregado();
    int compareTo(Object a);
}

