package com.mx.Imprementacion;

public class ImpFruta extends ImpGenerica {
	
	public void contar () {
		System.out.println("Tengo " + hash.size() + "frutas. ");
	}

}
