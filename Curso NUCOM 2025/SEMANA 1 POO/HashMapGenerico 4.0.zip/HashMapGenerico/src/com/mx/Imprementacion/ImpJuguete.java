package com.mx.Imprementacion;

public class ImpJuguete extends ImpGenerica {
	
	public void contar () {
		System.out.println("HAY " + hash.size() + "JUGUETES ");
	}

}
