package com.mx.Herramientas;

import java.util.ArrayList;
import java.util.List;

public class Principal {

	
	public static void main(String[] args) {
		
		
		List<Producto> productos = new ArrayList<>();
		
		// Agregamos algunos productos
		 productos.add(new Herramienta("Martillo","TRUPPER",15, 150.0, "MARTILLO PESADO","USADO PARA CLAVAR CLAVOS"));
	        productos.add(new Ropa("Pantalón de mezclilla","CUIDADO CON EL PERRO", 20,  300.0, "AZUL CIELO","MEDIANA"));
	        productos.add(new Herramienta("DESTORNILLADOR","TRUPPER",15, 150.0, "DE CRUZ","TORNILLAR O DESTORNILLAR TORNILLOS"));
	        productos.add(new Ropa("CAMISA","C&A", 20,  300.0, "AZUL Y BLANCO","GRANDE"));
	        
	        // Mostrar inventario
	        
	        
	        System.out.println("***** INVENTARIO *****");
	        for (Producto p : productos) {
	            p.mostrar();
	            System.out.println();
	}
}
}