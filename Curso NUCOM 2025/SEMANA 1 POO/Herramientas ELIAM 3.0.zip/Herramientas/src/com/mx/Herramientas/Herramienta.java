package com.mx.Herramientas;

public class Herramienta extends Producto {

	
	private String tipoDeH;
	private String Uso;
	
	public Herramienta () {
		
	}

	public Herramienta(String nombre, String marca, int stock, double precio, String tipoDeH, String uso) {
		super(nombre, marca, stock, precio);
		this.tipoDeH = tipoDeH;
		Uso = uso;
	}
	public void mostrar() {
        System.out.println("=== Herramienta ===");
        super.mostrar();
        System.out.println("Tipo: " + tipoDeH);
    }
	@Override
	public String toString() {
		return "Herramienta [nombre=" + nombre + ", marca=" + marca + ", stock=" + stock + ", precio=" + precio
				+ ", tipoDeH=" + tipoDeH + ", Uso=" + Uso + "]";
	}

	public String getTipoDeH() {
		return tipoDeH;
	}

	public void setTipoDeH(String tipoDeH) {
		this.tipoDeH = tipoDeH;
	}

	public String getUso() {
		return Uso;
	}

	public void setUso(String uso) {
		Uso = uso;
	}
	
	
}
