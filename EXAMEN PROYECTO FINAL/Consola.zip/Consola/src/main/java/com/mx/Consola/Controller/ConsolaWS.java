package com.mx.Consola.Controller;

import java.util.HashMap;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.mx.Consola.Domain.Consola;
import com.mx.Consola.Service.ConsolaServiceImp;

import io.swagger.v3.oas.annotations.Operation;

@RestController
@CrossOrigin("*")
@RequestMapping(path = "/consola")


public class ConsolaWS {

	
	@Autowired
	private ConsolaServiceImp service;
	
	//URI : http://localhost:8012/consola
	@Operation(summary = "Listar consola", description = "Lista todas las consolas traidas desde la base de datos")
	@GetMapping
	public ResponseEntity<?> listar(){
		List<Consola> consolas = service.listar();
		return (consolas.isEmpty()) ? ResponseEntity.noContent().build() : ResponseEntity.ok(consolas);
		
	}
	@Operation(summary = "Guardar  nueva consola", description = "Crea y almacena una nueva consola en la base de datos")
	@PostMapping
	public ResponseEntity<?> guardar(@RequestBody Consola c){
		Consola existe = service.validacion(c.getNombre(), c.getTipo());
		if (existe != null) {
			return ResponseEntity.status(HttpStatus.CONFLICT).build();
			} else {
				existe = service.guardar(c);
				return ResponseEntity.status(HttpStatus.CREATED).body(existe);
			}
	}
	@Operation(summary = "Editar consola", description = "Edita una consola existente y la actualiza")
	@PutMapping
	public ResponseEntity<?> editar(@RequestBody Consola c){
	Consola actual = service.guardar(c);
	return ResponseEntity.ok(actual);
		
	}
	@Operation(summary = "Eliminar consola", description = "Elimina una consola mediante el id de la consola de la base de datos")
	@DeleteMapping
	public ResponseEntity<?> eliminar(@RequestParam int idConsola){
		service.eliminar(idConsola);
		return ResponseEntity.noContent().build();	
		}
		@Operation(summary = "Buscar consola por ID", description = "Busca una consola mediante su ID en la base de datos y la muestra")
@GetMapping("buscar")
public ResponseEntity<?> buscar(@RequestParam int idConsola){
	Consola encontrado = service.buscar(idConsola);
	return (encontrado != null) ? ResponseEntity.ok(encontrado) : ResponseEntity.notFound().build();
}

@Operation(summary = "Buscar por consola y accesorios", description = "Busca una cosola mediante su ID y muestra los accesorios asociados a esa consola")
@GetMapping("accesorios/{consolaId}")
public ResponseEntity<?> accesorios(@PathVariable int consolaId){
	//List<Videojuego> v = service.traerVideojuegos(videojuegoId);
	//return (v.isEmpty()) ? ResponseEntity.noContent().build() : ResponseEntity.ok(v);
HashMap<String, Object> hash = service.conYAccesorios(consolaId);
return ResponseEntity.ok(hash);



}
	}

